package com.AluraLatam.ForoHub.domain.autor;

public record DatosAutenticacionAutor(
    long id,
    String correo,
    String contrasena
) {
}
