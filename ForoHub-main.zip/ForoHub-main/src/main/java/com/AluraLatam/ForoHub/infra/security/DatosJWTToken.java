package com.AluraLatam.ForoHub.infra.security;

public record DatosJWTToken(String jwtToken) {
}

